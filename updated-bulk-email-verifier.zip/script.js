document.getElementById("verifyEmails").addEventListener("click", () => {
  const fileInput = document.getElementById("emailFile");
  const manualEmails = document.getElementById("manualEmails").value;
  const progressDiv = document.getElementById("progress");
  const resultsDiv = document.getElementById("results");
  const invalidList = document.getElementById("invalidEmails");
  const summary = document.getElementById("summary");
  const downloadButton = document.getElementById("downloadValid");

  let emails = [];
  if (fileInput.files.length > 0) {
    const file = fileInput.files[0];
    const reader = new FileReader();
    reader.onload = function (e) {
      emails = e.target.result.split(/\r?\n/).map(email => email.trim());
      verifyEmails(emails);
    };
    reader.readAsText(file);
  } else if (manualEmails.trim()) {
    emails = manualEmails.split(",").map(email => email.trim());
    verifyEmails(emails);
  } else {
    alert("Please upload a file or enter emails manually.");
  }

  function verifyEmails(emailList) {
    const validEmails = [];
    const invalidEmails = [];
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    resultsDiv.classList.add("hidden");
    progressDiv.style.width = "0%";
    invalidList.innerHTML = "";
    downloadButton.classList.add("hidden");

    emailList.forEach((email, index) => {
      setTimeout(() => {
        if (emailRegex.test(email)) {
          validEmails.push(email);
        } else {
          invalidEmails.push(email);
        }

        const progress = ((index + 1) / emailList.length) * 100;
        progressDiv.style.width = `${progress}%`;

        if (index === emailList.length - 1) {
          showResults(validEmails, invalidEmails);
        }
      }, index * 50);
    });
  }

  function showResults(validEmails, invalidEmails) {
    resultsDiv.classList.remove("hidden");
    summary.textContent = `Valid Emails: ${validEmails.length}, Invalid Emails: ${invalidEmails.length}`;
    invalidEmails.forEach(email => {
      const li = document.createElement("li");
      li.textContent = email;
      invalidList.appendChild(li);
    });

    if (validEmails.length > 0) {
      downloadButton.classList.remove("hidden");
      downloadButton.onclick = () => downloadCSV(validEmails);
    }
  }

  function downloadCSV(data) {
    const csvContent = data.join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "valid_emails.csv";
    a.click();
    URL.revokeObjectURL(url);
  }
});
